<div style="margin: auto;width: 60%;">

	<div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
	<div class="alert alert-danger alert-dismissible" id="error" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>

    <!-- <button type="button" class="btn btn-primary my-4" data-toggle="modal" data-target="#exampleModalSkill">
Add Skill
</button> -->


<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModalSkill" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Skills</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
	
	<form id="register_form" name="form1" method="post">
		<div class="form-group">
			<label for="email">Skill Title:</label>
			<input type="text" class="form-control" id="sname" placeholder="e.g: Web Design" name="name">
		</div>
		
		<input type="button" name="save" class="btn btn-primary" value="Add" id="butsaveSkill">
	</form>

    </div>
      
    </div>
  </div>
</div>
    
	
</div>

<script>
$(document).ready(function() {
	

	$('#butsaveSkill').on('click',function() 
    {
		// $("#butsave").attr("disabled", "disabled");
		var name = $('#sname').val();
		var skill = 'skill';
		if(name!=""){
			$.ajax({
				url: "addSkill.php",
				type: "POST",
				data: {
					type: skill,
					name: name										
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						//$("#butsave").removeAttr("disabled");
						$('#register_form').find('input:text').val('');			
						$('#success').html('Added successful !'); 			
                        alert('Added successful !');
					}
					else if(dataResult.statusCode==201){
						$('#error').html('Skill already exists !');
                        alert('Skill already exists !');
					}
					
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});

});
</script>