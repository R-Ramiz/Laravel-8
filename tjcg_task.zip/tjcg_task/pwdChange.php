<?php
include 'basic_files/database.php';

$userId = $_POST['userId'];
$oldpwd = $_POST['oldpwd'];
$newpwd = $_POST['newpwd'];
$cnewpwd = $_POST['cnewpwd'];

$result = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$userId'");
$row = mysqli_fetch_assoc($result);
$password = $row['password'];

$regexp = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
$validPass = preg_match($regexp,$newpwd);


$checkPass = strcmp($password,$oldpwd);


if(!$validPass)
{
    echo json_encode(
        [
            'statusCode' => false,
            'data' => [],
            'message' => 'Please Enter Valid Password !!!'
        ]
    );

}else if($newpwd != $cnewpwd)
{
    echo json_encode(
        [
            'statusCode' => false,
            'data' => [],
            'message' => 'Password and Confirm Password Doesn\'t Match !!!'
        ]
    );

}else if($checkPass)
{
    echo json_encode(
        [
            'statusCode' => false,
            'data' => [],
            'message' => 'Old Password Doesn\'t Match !!!'
        ]
    ); 

}else{
    $updatepwd = "UPDATE `users` SET `password` = '$newpwd' WHERE `users`.`id` = '$userId'";
    mysqli_query($conn,$updatepwd);

    echo json_encode(
        [
            'statusCode' => true,
            'data' => [],
            'message' => 'Password Updated Successfully'
        ]
    );
}


?>