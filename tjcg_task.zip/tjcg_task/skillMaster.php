<?php

error_reporting(0);
session_start();

include 'basic_files/database.php';
include 'basic_files/upper.php';
include 'basic_files/navbar.php';

// include 'add_skills.php';

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  width: 130px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
  margin-top: 50px;
  
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.main {
  margin-left: 140px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* active user start */
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}


/* active user end */
</style>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.css">  
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">   

</head>
<body>

<div class="sidenav">
  <a href="home.php">Dashbord</a>
  <a href="userMaster.php">User Master</a>
  <a href="skillMaster.php">Skill Master</a>
  <a href="changePassword.php">Change Password</a>
</div>

<div class="main">
   <?php
   
   echo '<button type="button" class="btn btn-primary my-4" data-toggle="modal" data-target="#exampleModalSkill">
   Add Skill
   </button>';
   
   ?>  


    
<table id="example" class="display" style="width:100%; font-size:16px;">

   <thead>
    <tr>
      
        <th>Id</th>
        <th>Name</th>
        <th></th>
        <th>Action</th>
        
    </tr>
   </thead>

   <tbody>

   <?php   
   $numC = mysqli_query($conn,"SELECT * FROM `skills`");
   while($row = mysqli_fetch_assoc($numC))
   {
      $skillName = $row['name'];
      ?>
      <tr>
        <td><?= $row['id']; ?></td>
        
        <td><?= $row['name']; ?></td>
        <td><input type="text" name="skillName" id="skillName" value="<?= $skillName; ?>" hidden></td>
        
        <td>
          <button class="btn btn-info editUp" data-toggle="modal" data-target="#editModalSkill">Edit</button>
          <button class="btn btn-danger deleteUp" data-toggle="modal" data-target="#deleteModalSkill">Delete</a>
        </td>
  </tr>
   <?php
   }

   ?>
   </tbody>

   <tfoot>
    <tr>                
        <th>Id</th>
        <th>Name</th>
        <th></th>
        <th>Action</th>

    </tr>
   </tfoot>

</table>

</div>

</div>  

<!-- Modal forAdd Start-->
<div class="modal fade" id="exampleModalSkill" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Skills</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
	
	<form id="register_form" name="form1" method="post">
		<div class="form-group">
			<label for="email">Skill Title:</label>
			<input type="text" class="form-control" id="sname" placeholder="e.g: Web Design" name="name">
		</div>
		
		<input type="button" name="save" class="btn btn-primary" value="Add" id="butsaveSkill">
	</form>

    </div>
      
    </div>
  </div>
</div>
<script>
$(document).ready(function()
{
	
  $('#example').DataTable();

	$('#butsaveSkill').on('click',function() 
    {
		// $("#butsave").attr("disabled", "disabled");
		var name = $('#sname').val();
		var skill = 'skill';
		if(name!=""){
			$.ajax({
				url: "addSkill.php",
				type: "POST",
        dataType: 'JSON',
				data: {
					type: skill,
					name: name										
				},
				cache: false,
				success: function(dataResult)
          {					          
					if(dataResult.statusCode)
            {
					   alert('Added successful !');
             location.reload();
					}
					else if(dataResult.statusCode)
               {
					   alert('Skill already exists !');
					}
					
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});

});
</script>
<!-- Modal forAdd End-->


<script>

$(document).ready(function(){

$(document).on('click','.editUp',function()
{

   var fid = $(this).closest('tr').find('#skillName').val();
   $('#ename').val(fid);
   $('#edname').val(fid);
  
});


});

</script>



<!-- Modal forEdit Start-->
<div class="modal fade" id="editModalSkill" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Skills</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
	
	<form id="register_form" name="form1" method="post">

     <div class="form-group">
			<label for="email">Skill Title:</label>
			<input type="text" class="form-control" id="ename" value="" placeholder="e.g: Web Design" name="name">
      <input type="text" class="form-control" id="edname" value="" hidden>
    </div>
		
		<input type="button" name="edit" class="btn btn-primary" value="Edit" id="buteditSkill">
	</form>

    </div>
      
    </div>
  </div>
</div>


<script>
$(document).ready(function()
{

	$('#buteditSkill').on('click',function() 
    {
		var name = $('#ename').val();
    var edname = $('#edname').val();
		var skill = 'skill';
    
         
  	if(name!="")
    {
      
			$.ajax({
				url: "addSkill.php",
				type: "POST",
        dataType: 'JSON',
				data: {
					type: skill,
          edname: edname,
					editname: name										
				},
				cache: false,
				success: function(dataResult)
        {
          
          if(dataResult.statusCode) 
          {          
            alert(dataResult.message);
            location.reload();
            
          } else {
            alert(dataResult.message);
          }					
				},
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }       
        
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});

});
</script>
<!-- Modal forEdit End-->




<!-- Modal forDelete Start-->
<div class="modal fade" id="deleteModalSkill" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Skill</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body"> 
	
	<form id="register_form" name="form1" method="post">

     <div class="form-group">
       <input type="text" class="form-control" id="edname" value="" hidden>
       <label for="email">Are you Sure to Delete ?</p> </label>
    </div>
		
		<input type="button" name="delete" class="btn btn-danger" value="Delete" id="btndelete">
	</form>

    </div>
      
    </div>
  </div>
</div>


<script>
$(document).ready(function()
{

  $(document).on('click','.deleteUp',function()
  {

     var fid = $(this).closest('tr').find('#skillName').val();
   
     $('#ename').val(fid);
     $('#edname').val(fid);

  });


	$('#btndelete').on('click',function() 
    {
	    var edname = $('#edname').val();
	  	var deleted = 'Delete';
	
  	if(edname){
			$.ajax({
				url: "addSkill.php",
				type: "POST",
        data:
        {
					    deletename: edname,
              deleted: deleted					
				},
				cache: false,
				success: function(dataResult)
        {
          var dataResult = JSON.parse(dataResult);
         	if(dataResult.statusCode)
          {
              alert('Deleted Successfully !');
              location.reload();
					}
					else 
          {
             alert('Some Error Occurd !');
					}
					
				},
        error: function(XMLHttpRequest, textStatus, errorThrown) { 
        alert("Status: " + textStatus); alert("Error: " + errorThrown); 
    }      
			});
		}
		else{
			alert('Some Error');
		}
	});

});
</script>
<!-- Modal forDelete End-->

<?php

include 'basic_files/lower.php';

 ?>






