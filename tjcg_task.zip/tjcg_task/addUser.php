<?php
include 'basic_files/database.php';
//session_start();

	extract($_REQUEST);
	
	
	if(!empty($_POST['deleteuser'])) //if deleteuser isn't empty
	{
		
		$user = $_POST['deleteuser']; 
	
			$delete = mysqli_query($conn,"DELETE FROM `users` WHERE `users`.`id` = '$user'");
			if($delete)
			{
			   $delete = mysqli_query($conn,"DELETE FROM `user_skill` WHERE `user_skill`.`user_id` = '$user'");
				echo json_encode(
					[
						'statusCode' => true,
						'data' => [],
						'message' => 'User Deleted Successfully'
					]
					
				);
			}else{
				echo json_encode(
					[
						'statusCode' => false,
						'data' => [],
						'message' => 'Some Error Occured !'
					]
				);
			}
			
		





	}else{
		
		
		
		$file =	$_FILES['profilepic']['name'];
		$file_image		=	'';
		if($_FILES['profilepic']['name']!="")
		{
			extract($_REQUEST);
			$infoExt = getimagesize($_FILES['profilepic']['tmp_name']);
			if(strtolower($infoExt['mime']) == 'image/gif' || strtolower($infoExt['mime']) == 'image/jpeg' || strtolower($infoExt['mime']) == 'image/jpg' || strtolower($infoExt['mime']) == 'image/png'){
				$file	= preg_replace('/\\s+/', '-',$file);
				$path   = FOLDER_URL.$file;
				move_uploaded_file($_FILES['profilepic']['tmp_name'],$path);
				
			}else{
				echo 2;
			}
		}
		
	


	 $regexE = "/^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/";
	 $validEmail = preg_match($regexE,$email);

	
	 $regexp = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
	 $validPass = preg_match($regexp,$password);

	 $regexc = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
	 $validPassC = preg_match($regexc,$cpassword);

	 $phoneRx = regex = "/^(\s)*[\d\+\(\)\- x]{4,}$/";
	 $validPhone = preg_match($phoneRx,$phone);


	
	if($name == '')
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter the Name'
			]
			);

	}elseif(!$validEmail){
		
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Email'
			]
			);

	}elseif($validPass = false){
		
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Password'
			]
			);
	}elseif($validPassC = false){
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Confirm Password'
			]
			);
	}elseif($password != $cpassword)
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Password and Confirm Password Not match !!'
			]
			);
	}else
	{
		// echo $skills;


   
		date_default_timezone_set("Asia/Kolkata");
    	$date = new DateTime();
    	$today = $date->format('Y-m-d H:i:s'); 
		

		//	echo "<pre>"; print_r($skills);die;

		$sql = "INSERT INTO `users` (`type`, `name`, `email`, `password`, `mobile`, `profile_pic`, `status`, `address`, `birthdate`, `created_at`, `updated_at`) VALUES ('$typeau', '$name', '$email', '$password', '$phone', '$file', 'active', '$city', '$birthdate', '$today', current_timestamp())";
		
		if ($conn->query($sql) === TRUE) {
		$last_if = $conn->insert_id;
		$last_id = $last_if+1;

		echo "New record created successfully. Last inserted ID is: " . $last_id;
	  } else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	  }


		if (mysqli_query($conn, $sql))
		 {		
		 $myId = [];
		 foreach($skills as $addSkill)
		 {
				$myId = $addSkill;
				$skillInsert = mysqli_query($conn,"INSERT INTO `user_skill` (`user_id`, `skill_id`, `created_at`, `updated_at`) VALUES ('$last_id', '$myId', '$today', current_timestamp())");
		 }
		echo json_encode(
			[
				'statusCode' => true,
				'data' => $skills,
				'message' => 'Done'
			]
		);
		} 
		else {
		echo json_encode(
			[
				'statusCode' => false,
				'data' => [],
				'message' => 'Sorry'
			]
		);
		}
		// mysqli_close($conn);

	}

}

?>



