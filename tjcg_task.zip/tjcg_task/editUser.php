<?php
include 'basic_files/database.php';
//session_start();

	extract($_REQUEST);
	
	
		
		$file =	$_FILES['profilepic2']['name'];
		$file_image		=	'';
		if($_FILES['profilepic2']['name']!="")
		{
			extract($_REQUEST);
			$infoExt = getimagesize($_FILES['profilepic2']['tmp_name']);
			if(strtolower($infoExt['mime']) == 'image/gif' || strtolower($infoExt['mime']) == 'image/jpeg' || strtolower($infoExt['mime']) == 'image/jpg' || strtolower($infoExt['mime']) == 'image/png'){
				$file	= preg_replace('/\\s+/', '-',$file);
				$path   = FOLDER_URL.$file;
				move_uploaded_file($_FILES['profilepic2']['tmp_name'],$path);
				
			}else{
				echo 2;
			}
		}
		
	


	 $regexE = "/^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/";
	 $validEmail2 = preg_match($regexE,$email2);
	
	 $regexp = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
	 $validPass2 = preg_match($regexp,$password2);

	 $regexc = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/";
	 $validPassC = preg_match($regexc,$cpassword2);
	
		

	 $phoneRx = "/^(\s)*[\d\+\(\)\- x]{4,}$/";
	 $validPhone = preg_match($phoneRx,$phone2);


	if($name2 == '')
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter the Name'
			]
			);

	}elseif(!$validEmail2){
		
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Email'
			]
			);

	}elseif(empty($skillsE)){
        echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Select atlist one skill'
			]
			);

    }elseif(!$validPhone)
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter valid Mobile Number Only'
			]
			);
  
	}
	elseif(empty($password2))
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter Password!!'
			]
			);
	}
    elseif($password2 != $cpassword2)
	{
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Password and Confirm Password Not match !!'
			]
			);
	}
	
    elseif(!$validPass2){
		
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Password'
			]
			);
	}elseif($validPassC2 = false){
		echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Enter Valid Confirm Password'
			]
			);
	}elseif($validPass2 == 0){
        echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter Valid Password!!'
			]
			);
    }
    elseif($cpassword2 == ''){
        echo json_encode(
			[
				'statusCode' => false,
				'message' =>'Please Enter Confirm Password!!'
			]
			);
    }
	else
	{
		date_default_timezone_set("Asia/Kolkata");
    	$date = new DateTime();
    	$today = $date->format('Y-m-d H:i:s'); 
		
		if(!empty($file))
		{
			$sql = "UPDATE `users` SET `type` = '$typeau2', `name` = '$name2', `email` = '$email2', `password` = '$password2', `mobile` = '$phone2', `profile_pic` = '$file', `address` = '$city2', `birthdate` = '$birthdate2' WHERE `users`.`id` = $idup";
		}else{
			$sql = "UPDATE `users` SET `type` = '$typeau2', `name` = '$name2', `email` = '$email2', `password` = '$password2', `mobile` = '$phone2',`address` = '$city2', `birthdate` = '$birthdate2' WHERE `users`.`id` = $idup";
		}

		if ($conn->query($sql) === TRUE)
		{
	         $deleteSkill = mysqli_query($conn,"DELETE FROM `user_skill` WHERE `user_id` = '$idup'");
			 foreach($skillsE as $addSkill)
			 {
				$myId = $addSkill;
				$skillInsert = mysqli_query($conn,"INSERT INTO `user_skill` (`user_id`, `skill_id`,`created_at`) VALUES ('$idup', '$myId','$today')");
			 }
				echo json_encode(
					[
						'statusCode' => true,
						'message' =>'Updated !!'
					]
				);		
		}else
		 {	
			echo json_encode(
						[
							'statusCode' => false,
							'message' =>'Update Else!!'
						]
						);
			echo "Error: " . $sql . "<br>" . $conn->error;
	  	 }


		
	}



?>



