<?php
session_start();
unset($_SESSION["email"]);
unset($_SESSION["password"]);
header("Location:index.php");



session_unset();

// destroy the session
session_destroy();
?>


 