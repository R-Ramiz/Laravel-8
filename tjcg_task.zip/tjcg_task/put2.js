

// Validate name
  $('#usercheck2').hide();	
	let usernameError2 = false;
	$('#name2').on('keyup',function () {
		validateUsername2();
	});	
	function validateUsername2()
	{
		let usernameValue2 = $('#name2').val();
		if (usernameValue2.length == '') {
		$('#usercheck2').show();
			usernameError2 = false;
			return false;
			}
		else if((usernameValue2.length < 3)||
				(usernameValue2.length > 10)) {
			$('#usercheck2').show();
			$('#usercheck2').html("**length of username must be between 3 and 10");
      usernameError2 = false;
      return false;
    }
		else {
      $('#usercheck2').hide();
      usernameError2 = true;
    }
	}

// Validate Mobile
$('#mobilecheck2').hide();	
let phoneError2 = false;
$(document).on('keyup',function () {
validatePhone2();
});	
function validatePhone2()
{
let phoneValue2 = $('#phone2').val();
var regex = /^(\s)*[\d\+\(\)\- x]{4,}$/;
  if (phoneValue2.length == '')
  {
    $('#mobilecheck2').show();
	  phoneError2 = false;
	  return false;
	}else if(!(regex.test(phoneValue2)))
  {
     $('#mobilecheck2').show();
     $('#mobilecheck2').html("**Insert Number Only");
     phoneError2 = false;
     return false;

  }
else if((phoneValue2.length < 10)||
		(phoneValue2.length > 10)) {
	$('#mobilecheck2').show();
	$('#mobilecheck2').html("**length of Mobilenumber must be 10");
  phoneError2 = false;
  return false;
}
else {
  phoneError2 = true;
	$('#mobilecheck2').hide();
  return false;
	}
}

// Validate Address
$('#addresscheck2').hide();	
let addressError2 = false;
$(document).on('keyup','#city2',function () {
validateCity2();
});	
function validateCity2()
{
let cityValue2 = $('#city').val();
if (cityValue2.length == '') {
$('#addresscheck2').show();
	addressError2 = false;
	return false;
	}
else if((cityValue2.length == '')) {
	$('#addresscheck2').show();
	$('#addresscheck2').html("**Address must be Filld");
	 addressError2 = false;
	return false;
	}
else {
  addressError2 = true;
  $('#addresscheck2').hide();
  return false;
	}
}

// Validate Birthdate
$('birthcheck2').hide();	
let birthError2 = false;
$(document).on('keyup','#birthdate',function () {
	validateBirth2();
});	
function validateBirth2()
{
	let birthValue2 = $('#birthdate2').val();
 	if (birthValue2.length == '') {
	$('birthcheck2').show();
		birthError2 = false;
		return false;
		}
	else {
    $('birthcheck2').hide();
    birthError2 = true;
    return false;
		}
}

// Validate skill
$('#skillcheck2').hide();	
let skillError2 = false;
$(document).on('keyup','#skills2',function ()
{
	validateSkills2();
});	
function validateSkills2()
{
	let skillValue2 = $('#skills2').val();
  if (skillValue2.length == '') {
	$('#skillcheck2').show();
		skillError2 = false;
		return false;
		}
	else {
    $('#skillcheck2').hide();
    skillError2 = true;
    return false;
		}
}

// Validate Profile
$('#profilecheck2').hide();	
let profileError2 = false;
$('#profilepic2').keyup(function () {
	validateProfile2();
});	
function validateProfile2()
{
	let profileValue = $('#profilepic2').val();
  if (profileValue.length == '') {
	$('#profilecheck2').show();
  profileError2 = false;
		return false;
		}
	else {
    $('#profilecheck2').hide();
    profileError2 = true;
		}
}


// Validate Password
$('#passcheck2').hide();
let passwordError2 = true;
$('#password2').keyup(function () {
	validatePassword2();
});
function validatePassword2() 
{
	let passwrdValue2 =
		$('#password2').val();
	if (passwrdValue2.length == '') {
		$('#passcheck2').show();
		passwordError2 = false;
		return false;
	}
  var regex2 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if(regex2.test(passwrdValue2))
  {

	if ((passwrdValue2.length < 8)||
		(passwrdValue2.length > 10)) {
		$('#passcheck2').show();
		$('#passcheck2').html("**length of your password must be between 8 and 10");
		$('#passcheck2').css("color", "red");
		passwordError2 = false;
		return false;
	} else {
		$('#passcheck2').hide();
    passwordError2 = true;
	}
 }
 else{

   $('#passcheck2').html("**Min characters 8 digit Atleast 1 uppercase, lowercase and special character");
   $('#passcheck2').css("color", "red");
 }
}

		
// Validate Confirm Password
$('#conpasscheck2').hide();
	let confirmpasswordError2 = true;
	$('#cpassword').keyup(function () {
		validateConfirmPasswrd2();
	});
	function validateConfirmPasswrd2() 
  {
		let confirmPasswordValue2 =
			$('#cpassword2').val();
		let passwrdValue2 =
			$('#password2').val();

    if(confirmPasswordValue2 == '')
    {
      $('#conpasscheck2').show();
			$('#conpasscheck2').html(
				"**Please Insert the Cofirm Password");
			$('#conpasscheck2').css(
				"color", "red");
			confirmpasswordError2 = false;
			return false;
		
    }else
    {

     if(passwrdValue2 != confirmPasswordValue2) 
     {
			$('#conpasscheck2').show();
			$('#conpasscheck2').html(
				"**Password didn't Match");
			$('#conpasscheck2').css(
				"color", "red");
			confirmpasswordError2 = false;
			return false;
		} else {
			confirmpasswordError2 = true;
			$('#conpasscheck2').hide();
      return false;
		}
   }
	}

  var emailError2 = false;
  $('#emailvalid2').hide();
  $('#email2').on('keyup',function () {
		validateEmail2();
	});	
	
  function validateEmail2()
  {    
    var regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    var email = $('#email').val();
	  if(email=='')
    {
      $('#emailvalid').show();
      emailError2 = false;
    }

	  if(regex.test(email))
    {		
		  emailError2 = true;
		}
		else{
			
			emailError2 = false;
      console.error('RAMIZ');
		}
	

  }


