<?php
	include 'basic_files/database.php';
	session_start();

	if(isset($_POST['name']))
	{

		$name = $_POST['name'];
		$find = "SELECT * FROM `skills` WHERE `name` = '$name'";
		$chk = mysqli_query($conn,$find);
		if (mysqli_num_rows($chk)>0)
		{
			echo json_encode(
			[
				'statuscode' => false,
				'data' => [],
				'message' => 'Skill Already Exist !!'
			]);

		}else
		{
			mysqli_query($conn,"INSERT INTO `skills` (`name`) VALUES ('$name')");
			
				echo json_encode(
					[
						'statusCode' => true,
						'data' => [],
						'message' => 'Skill Inserted Successfully !'
					]				
				);			
			 
			

			}		

	}
	elseif(isset($_POST['fetchid']))
	{

		$fid = $_POST['fetchid']; //$fid contains name
		

		$find = "SELECT * FROM `skills` WHERE `name` = '$fid'";
		$chk = mysqli_query($conn,$find);
		if (mysqli_num_rows($chk)>0)
		{
			echo json_encode(array("statusCode"=>201));	

		}else{
			
			echo json_encode(array("statusCode"=>200));
		}

	}elseif(isset($_POST['edname']))
	{
		$editname = $_POST['editname'];
		$edname = $_POST['edname'];

		$chk = mysqli_query($conn,"SELECT * FROM `skills` WHERE `name` = '$editname'");
		
		if (mysqli_num_rows($chk)>0)
		{
			echo json_encode(
				[
					'statusCode' => false,
					'data' => [],
					'message' => 'Skill Already Exist'
				]
			);	

		}else{
			
			mysqli_query($conn,"UPDATE `skills` SET `name` = '$editname' WHERE `skills`.`name` = '$edname'");
			echo json_encode(
				[
					'statusCode' => true,
					'data' => [],
					'message' => 'Skill Updated Successfully !'
				]
			);
		}
		
	}

	elseif(isset($_POST['deletename']))
	{
		$skill = $_POST['deletename'];
		$gid = mysqli_query($conn,"SELECT * FROM `skills` WHERE `name` = '$skill'");

		$data = mysqli_fetch_assoc($gid);
		$skillid = $data['id'];
		// echo $skillid;

		$delete = mysqli_query($conn,"DELETE FROM `skills` WHERE `skills`.`name` = '$skill'");
		if($delete)
		{	
			$ud = mysqli_query($conn,"DELETE FROM `user_skill` WHERE `user_skill`.`skill_id` = '$skillid'");
 			echo json_encode(
				[
					'statusCode' => true,
					'data' => [],
					'message' => 'Skill Deleted Successfully'
				]
			);
		}else{
			echo json_encode(
				[
					'statusCode' => false,
					'data' => [],
					'message' => 'Some Error Occured !'
				]
			);
		}
		
	}


?>