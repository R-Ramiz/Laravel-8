<?php

error_reporting(0);
session_start();

include 'basic_files/database.php';
// include 'basic_files/upper.php';
include 'basic_files/navbar.php';

session_start();
  if (!isset($_SESSION["email"]))
   {
      header("location: index.php");
   }

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
  font-size: 16px;
}

.sidenav {
  width: 130px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
  margin-top: 50px;
  
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.main {
  margin-left: 140px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* active user start */
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}


/* active user end */
</style>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.css">  
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.js"></script>
    <script>

    $(document).ready( function () 
    {
           $('#example').DataTable();

    });

    </script>


</head>
<body>


<div class="sidenav">
  <a href="home.php">Dashbord</a>
  <a href="userMaster.php">User Master</a>
  <a href="skillMaster.php">Skill Master</a>
  <a href="changePassword.php">Change Password</a>
</div>

<div class="main">
  
<!-- Button trigger modal -->
   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Add User
</button>
<br>

 
<table id="example" class="display" style="width:100%; font-size:16px;">

        <thead>
            <tr>
                <th>Id</th>
                <th>Profile Pic.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Status</th>
                <th>Action</th>

            </tr>
        </thead>

        <tbody>
        <?php   

      $numC = mysqli_query($conn,"SELECT * FROM `users`");
      while($row = mysqli_fetch_assoc($numC))
      { ?>
           <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['prifile_pic']; ?></td>
                <td><?= $row['name']; ?></td>
                <td><?= $row['email']; ?></td>
                <td><?= $row['mobile']; ?></td>

                <td>
                  
                <?php
                if($row['status']=="active")
                {
                    ?>
                  <form action="" method="post">
                    <input type="checkbox" name="status" class="check" onchange="status();" id="active" checked>                  
                  </form>  

                  <?php
                  }else{
                    ?>
                  <form action="" method="post">

                    <input type="checkbox" name="status" class="check" id="active">
                    
                  </form>  
                  
                  <?php
                  }
                  ?>
                </td>

                <td>
          <a href=""  class="btn btn-info">Edit</a>
          <a href="" class="btn btn-danger">Delete</a>

                </td>

          </tr>
        <?php
      }

    ?> 

        </tbody>

        <tfoot>
            <tr>                
                <th>Id</th>
                <th>Profile Pic.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th>Status</th>
                <th>Action</th>

            </tr>
        </tfoot>

</table>



<!-- Modal ALL Start  111--> 


<!-- Modal -->
<div class="modal fade" style="font-size: 16px;" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="container">
    
          <div>
        
        <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </div>
        
        <form id="fupForm" name="form1" method="post" onsubmit="return checkValidation()" enctype="multipart/form-data">
            <div class="row">
    
                  <div class="col-lg-6" >   
                    
                        <div class="form-group">
                          <label for="exampleFormControlTextarea1">User Type:</label>
                          <input type="radio" name="typeau" id="typeauc" value="admin">Admin
                          
                          <input type="radio" name="typeau" checked="checked" id="typeaub" value="user"> User

                        </div>           
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Name</label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name" maxlength="255" required>
                        </div>
    
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="e.g.: abc@xyz.com" required>
                        </div> 
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Mobile</label>
                                <input type="tel" class="form-control" id="phone" name="phone" minlength="10" maxlength="10" size="10" placeholder="ex.8980140000" required>
                        </div>
    
                        
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Address</label>
                            <!-- <input type="text" name="city" id="city"> -->
                            <textarea class="form-control" name="city" id="city" rows="3" required></textarea>
                        </div>

    
                    </div> 
    
                <div class="col-lg-6 ">       
                        
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Birthday</label>
                                <input type="date" name="birthdate" id="birthdate" class="form-control datepicker" required>
                            </div>
    
                                 
                            <div class="form-group">
                              <label for="formGroupExampleInput2">Skills:</label>
                                <select class="selectpicker form-control" name="skills" id="skills" multiple data-live-search="true" required>
                                      <option>Mustard</option>
                                      <option>Ketchup</option>
                                      <option>Relish</option>
                               </select>
                            </div>
    
                      
                            <div class="custom-file">
                               <input type="file"  onchange="readURL(this);" class="custom-file-input" id="profilepic" name="profilepic" required>
                               <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                             </div>
                    
                            <div class="form-group">
                                <img src="#"  id="blah" class="form-group" alt="">
                            </div>
    
                            <div class="form-group">
                                    <label for="formGroupExampleInput2">Password</label>
                                    <input type="password" class="form-control" name="password" id="password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" id="password"   data-toggle="tooltip" data-placement="top" title="Min characters 8 digit Atleast 1 uppercase, lowercase and special character" required>                    
                            </div>
    
    
                            <div class="form-group">
                                    <label for="formGroupExampleInput2">Confirm Password</label>
                                    <input type="password" class="form-control" id="cpassword" name="cpassword" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" placeholder="Re-enter Password" required>
                            </div>
                    
                </div>
                        
                 
            </div>
                <div class="row text-center">
                    <div class="col">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary" name="butsave" id="butsave">Submit</button>
                        </div>
                    </div>        
                </div>
    
        </form>
          </div>
    
    </div>


  </div>
     
    </div>
  </div>
</div></div>
<!-- Modal ALL END -->



<!-- main div End down -->
</div>  

<script>
function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<script>

function checkValidation()
{
    let fname = document.getElementById('name').value;
    if(fname == "Sahi")
    {
       
        alert('Sahi');
        done();
        return true;
    }

}
</script>


<script>
 
    
      if(checkValidation)
      {
             done();
             alert('checkValidation True');
      
      }else{
          done();
           alert('checkValidation False');
      }


      $(document).ready(function(){

          

    
     $('#butsave').on('click',function()
    {

    var data = new FormData('#fupForm');

    var typeau =  $('input[name="typeau"]:checked').val();
    var name = $('#name').val();
		var email = $('#email').val();
		var phone = $('#phone').val();
		var city = $('#city').val();  
	  var birthdate = $('#birthdate').val();
		var skills = $('#skills').val();
		var profilepic = $('#profilepic').val();
	  var password = $('#password').val();
    var cpass = $('#cpassword').val();

        // function you can use:
        function getSecondPart(profilepic)
         {
            var profilepic = profilepic.split('fakepath')[1];
            return profilepic.slice(1, );
        }

        // use the function:
       var profilepic = getSecondPart(profilepic);

        console.log(password);

         if(password != cpass)
         {
             alert('Password and Confirm Password not match');
             
         }else{


        
    if(name!="" && email!="" && phone!="" && city!="")
    {


			$.ajax({
				url: "addUser.php",
				type: "POST",
        dataType: 'JSON',
				data: {
          type:1,
          typeau: typeau,
					name: name,
					email: email,
					phone: phone,
					city: city,
          birthdate: birthdate,
          // skills: skills
          profilepic: profilepic,
          password: password

				},
				cache: false,
				success: function(dataResult){
				//	var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
            $("#butsave").removeAttr("disabled");
						$('#fupForm').find('input:text').val('');
						$("#success").show();
						$('#success').html('Data added successfully !'); 						
					}
					else if(dataResult.statusCode==201){
					   alert("Error occured !");
					}
					
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}

      }

	}
});

});
</script>

<script>

$(document).ready(function(){

  $(document).on('change',.check,function(){

      alert('Hello');

  });

})

</script>
   
<?php

include 'basic_files/lower.php';

 ?>






  