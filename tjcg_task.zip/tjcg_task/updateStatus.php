<?php
	include 'basic_files/database.php';
	session_start();
    
	if($_POST['status'])
	{
        $id = $_POST['id'];
        $numC = mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$id'");
        $row = mysqli_fetch_assoc($numC);
        $status = $row['status'];

        if($status == 'active')
        {
            
        $uncheck = "UPDATE `users` SET `status` = 'deactive' WHERE `users`.`id` = '$id'";
        $done = mysqli_query($conn,$uncheck);
        if($done)
        {

            echo json_encode(
                [
                    'statusCode' => true,
                    'message' => 'User De-activated Successfully !!'
                ]
            );
        }else{

            echo json_encode(
                [
                    'statusCode' => false,
                    'message' => 'Some Error , Please Try Again !!'
                ]
            );
         }
        }else
        {
              
        $check = "UPDATE `users` SET `status` = 'active' WHERE `users`.`id` = '$id'";
        $done = mysqli_query($conn,$check);
        if($done)
        {

            echo json_encode(
                [
                    'statusCode' => true,
                    'message' => 'User Activated Successfully !!'
                ]
            );
        }else{

            echo json_encode(
                [
                    'statusCode' => false,
                    'message' => 'Some Error , Please Try Again !!'
                ]
            );
         }
        }

    }

?>