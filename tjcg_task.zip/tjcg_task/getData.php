<?php
	
    include 'basic_files/database.php';
	session_start();

    $id = $_POST['uid'];

    $getData =  mysqli_query($conn,"SELECT * FROM `users` WHERE `id` = '$id';");
    $row = mysqli_fetch_assoc($getData);
    // echo "<pre>"; print_r($row); 


    $getSkills =  mysqli_query($conn,"SELECT `skill_id` FROM `user_skill` WHERE `user_id` = '$id'");
    // $row2 = mysqli_fetch_assoc($getSkills);

    $skill_id_array = [];

    if(mysqli_num_rows($getSkills) > 0) 
    {
        while($row2 = mysqli_fetch_assoc($getSkills))
        {
            $skill_id_array[] = $row2['skill_id'];
        }
    }

    // $data = array();
    // if(mysqli_num_rows($result) > 0)
    // {
    //     while($row = mysqli_fetch_assoc($result))
    //     {
    //         $data = $row;
    //     }
    // }
    // print_r($row2);
        $type = $row['type'];
        $name = $row['name'];
        $email = $row['email'];
        $mobile = $row['mobile'];
        $address = $row['address'];
        $birthdate = $row['birthdate'];
        $profilepic = $row['profile_pic'];
      
    if($getData){

        echo json_encode(
                [
                        'statusCode' => true,
                        'data'=> array(
                        "type" => "$type",
                        "name"=>"$name",
                        "email"=>"$email",
                        "mobile"=>"$mobile",
                        "address"=>"$address",
                        "birthdate"=>"$birthdate",
                        "profilepic"=>"$profilepic"
                    ),
                    'message'=>'we give you data',
                    'skillarr'=> $skill_id_array
                ]
        );

    }

?>