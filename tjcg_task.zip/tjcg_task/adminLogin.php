<?php
	include 'basic_files/database.php';
	

	
		$email=$_POST['email'];
		$password=$_POST['password'];
		// $check=mysqli_query($conn,"select * from crud where email='$email' and password='$password'");
		$check=mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$email' AND `password`='$password' AND `type` ='admin'");
        if (mysqli_num_rows($check)>0)
		{
			session_start();
			$_SESSION['email']=$email;
		
			echo json_encode(array("statusCode"=>200));
		}
		else{
			echo json_encode(array("statusCode"=>201));
		}
		mysqli_close($conn);
	




    ?>