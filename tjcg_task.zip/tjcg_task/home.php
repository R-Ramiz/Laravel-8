<?php
error_reporting(0);
session_start();
include 'basic_files/database.php';
include 'basic_files/upper.php';
include 'basic_files/navbar.php';

$numA = mysqli_query($conn,"SELECT * FROM `users` WHERE `type`='user'");
$searchA = mysqli_num_rows($numA);

$numB = mysqli_query($conn,"SELECT * FROM `users` WHERE `type`='admin'");
$searchB = mysqli_num_rows($numB);

$numC = mysqli_query($conn,"SELECT * FROM `users` WHERE `status`='active'");
$searchC = mysqli_num_rows($numC);

$numD = mysqli_query($conn,"SELECT * FROM `users` WHERE `status`!='active'");
$searchD = mysqli_num_rows($numD);

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  width: 130px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
  margin-top: 50px;
  
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.main {
  margin-left: 140px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* active user start */
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}


/* active user end */
</style>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.css">  
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.js"></script>
    <script>

    $(document).ready( function () 
    {
           $('#example').DataTable();

    });

    </script>
</head>
<body>

<div class="sidenav">
  <a href="#">Dashbord</a>
  <a href="userMaster.php">User Master</a>
  <a href="skillMaster.php">Skill Master</a>
  <a href="changePassword.php">Change Password</a>
</div>

<div class="main">
  
<!-- Cards Start -->
  <div class="container my-3"> 

 <!-- First Row - Start -->
     <div class="row mx-1">
      <div class="row-lg-6">
        <!-- Normal Users -->
        <div class="card" style="width: 18rem;">
          <div class="card-body card-dark">
            <h5 class="card-title">Normal Users:</h5>
            <h6 class="card-subtitle mb-2 text-muted"><?php echo $searchA; ?></h6>
          </div>
        </div>
     </div>    
    <div class="row-lg-6">
    <!--Admin Users: -->
    <div class="card mx-2" style="width: 18rem;">
      <div class="card-body card-dark">
        <h5 class="card-title">Admin Users: </h5>
        <h6 class="card-subtitle mb-2 text-muted"><?php echo $searchB; ?></h6>
      </div>
    </div>
    
    </div>

    </div>
    <!-- First Row - End - Up -->

      <br>
      <!-- Second Row - Start -->
      <div class="row mx-1">
      <div class="row-lg-6">
      <!-- Active Users:  -->
      <div class="card" style="width: 18rem;">
        <div class="card-body card-dark">
          <h5 class="card-title">Active Users:</h5>
          <h6 class="card-subtitle mb-2 text-muted"><?php echo $searchC; ?></h6>
        </div>
      </div>
      </div>
      <div class="row-lg-6">
      <!--Inactive Users: -->
      <div class="card mx-2" style="width: 18rem;">
      <div class="card-body card-dark">
      <h5 class="card-title">Inactive Users: </h5>
      <h6 class="card-subtitle mb-2 text-muted"><?php echo $searchD; ?></h6>
      </div>
      </div>

    </div>
      <!-- Second Row - End Up -->

    </div>
<!-- Cards End -->
<br>
<h2 class="text-center">-*--*--*--*-Currently Active Users-*--*--*--*-</h2>
<br>
<!-- Active Users - Start -->
 <table id="example" class="display" style="width:100%; font-size:16px;">

<thead>
    <tr>
    <th style="width:20%;">Id</th>
    <th style="width:40%;">Name</th>
    <th style="width:40%;">Email</th>
    <th style="width:40%;">Mobile</th>
    <th style="width:40%;">Status</th>

    </tr>
</thead>

<tbody>
<?php   

$numC = mysqli_query($conn,"SELECT * FROM `users`");

while($row = mysqli_fetch_assoc($numC))
{ ?>
   <tr>
        <td><?= $row['id']; ?></td>
        <td><?= $row['name']; ?></td>
        <td><?= $row['email']; ?></td>
        <td><?= $row['mobile']; ?></td>
        <td><?= $row['status']; ?></td>
       
  </tr>
<?php
}

?>

   


</tbody>

<tfoot>
    <tr>                
    <th style="width:20%;">Id</th>
    <th style="width:40%;">Name</th>
    <th style="width:40%;">Email</th>
    <th style="width:40%;">Mobile</th>
    <th style="width:40%;">Status</th>
    </tr>
</tfoot>

</table>
  

<!-- Active Users - End-Up -->

  
</div>

</div>  


   
<?php

include 'basic_files/lower.php';

 ?>


<!-- 
<tr class="header">
    <th style="width:20%;">Id</th>
    <th style="width:40%;">Name</th>
    <th style="width:40%;">Email</th>
    <th style="width:40%;">Mobile</th>
    <th style="width:40%;">Status</th>
    
  </tr>

  <?php   

    // while($row = mysqli_fetch_assoc($numC))
    // {
    //     echo "<tr>";
    //     echo "<td>" . $row['id'] . "</td>";
    //     echo "<td>" . $row['name'] . "</td>";
    //     echo "<td>" . $row['email'] . "</td>";
    //     echo "<td>" . $row['mobile'] . "</td>";
    //     echo "<td>" . $row['status'] . "</td>";
    //     echo "</tr>";
    // } -->