<?php
	// $servername = "localhost";
	// $username = "root";
	// $password = "";
	// $db="task_tjcg";
	// $conn = mysqli_connect($servername, $username, $password,$db);


	$servername = "localhost";
	$username = "root";
	$password = "";
	$db="task_tjcg";
	/*Create connection*/
	$conn = mysqli_connect($servername, $username, $password,$db);

	define('BASE_URL','http://localhost/tjcg_task/');
	define('FOLDER_URL','uploads/');

?>