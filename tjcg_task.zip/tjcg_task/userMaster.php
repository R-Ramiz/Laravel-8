<?php

error_reporting(0);
session_start();

include 'basic_files/database.php';
// include 'basic_files/upper.php';
include 'basic_files/navbar.php';

session_start();
  if (!isset($_SESSION["email"]))
   {
      header("location: index.php");
   }

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
  font-size: 16px;
}

.sidenav {
  width: 130px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
  margin-top: 50px;
  
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.main {
  margin-left: 140px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
/* active user start */
* {
  box-sizing: border-box;
}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  background-repeat: no-repeat;
  width: 100%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

#myTable {
  border-collapse: collapse;
  width: 100%;
  border: 1px solid #ddd;
  font-size: 18px;
}

#myTable th, #myTable td {
  text-align: left;
  padding: 12px;
}

#myTable tr {
  border-bottom: 1px solid #ddd;
}

#myTable tr.header, #myTable tr:hover {
  background-color: #f1f1f1;
}

#imgR{
  width: 100px;
  height: 100px;
}


/* active user end */
</style>


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.1/css/jquery.dataTables.css">  

    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.1/js/jquery.dataTables.js"></script>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">   

    <script>


    </script>


</head>
<body>


<div class="sidenav">
  <a href="home.php">Dashbord</a>
  <a href="userMaster.php">User Master</a>
  <a href="skillMaster.php">Skill Master</a>
  <a href="changePassword.php">Change Password</a>
</div>

<div class="main">
  
<!-- Button trigger modal -->
   <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
       Add User
   </button>
<br>

 
<table id="example" class="display" style="width:100%; font-size:16px;">

        <thead>
            <tr>
                <th>Id</th>
                <th>Profile Pic.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th></th>
                <th>Status</th>
                <th>Action</th>

            </tr>
        </thead>

        <tbody>
        <?php   

      $numC = mysqli_query($conn,"SELECT * FROM `users`");
      while($row = mysqli_fetch_assoc($numC))
      { 
      

        ?>
        
        
        <tr>
          <td><?= $row['id']; ?></td>
          <td>
                  <img src="<?= BASE_URL.FOLDER_URL.$row['profile_pic']; ?>"  id="imgR" class="form-group" alt="">
                
                </td>
                <?php
                      $deleteid = $row['id'];
                ?>
                <td><?= $row['name']; ?></td>
                <td><?= $row['email']; ?></td>
                <td><?= $row['mobile']; ?></td>
                <td><input type="text" name="email" id="emailid" value="<?= $deleteid; ?>" hidden></td>
                <td>
                  
                <?php
                if($row['status']=="active")
                {
                  ?>
                  <input type="text" name="getid" id="getid" value="" hidden>
                  <form action="" method="post">
                    <input type="checkbox" name="status" class="check" id="activeChked" data-toggle="modal" data-target="#exampleModalStatus" checked>                  
                  </form>  

                  <?php
                  }else{
                    ?>
                  <form action="" method="post">

                    <input type="checkbox" name="status" class="check" id="activeChk" data-toggle="modal" data-target="#exampleModalStatus">
                    
                  </form>  
                  
                  <?php
                  }
                  ?>
                </td>

                <td>
          
          <input type="text" name="upid" id="upid" value="" hidden>
          <button class="btn btn-info updateUp" data-toggle="modal" data-target="#editModalEdit">Edit</button>

          <input type="text" class="form-control" id="edname" value="" hidden>

          <button type="button" id="deleteUp" class="btn btn-primary deleteUp" data-toggle="modal" data-target="#exampleModalDelete">
            Delete
          </button>
                </td>

          </tr>
        <?php
      }

    ?> 

        </tbody>

        <tfoot>
            <tr>                
                <th>Id</th>
                <th>Profile Pic.</th>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile</th>
                <th></th>
                <th>Status</th>
                <th>Action</th>

            </tr>
        </tfoot>

</table>



<!-- Modal ALL Start  111--> 


<!-- Modal- Add User Start -->
<div class="modal fade" style="font-size: 16px;" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="container">
    
          
        <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </div>
        
        <form id="fupForm" class="fupForm" name="form1" method="post" enctype="multipart/form-data">
            <div class="row">
    
                  <div class="col-lg-6" >   
                    
                        <div class="form-group">
                          <label for="exampleFormControlTextarea1">User Type:</label>

                          <input type="radio" name="typeau" id="typeauc" value="admin">Admin                          
                          <input type="radio" name="typeau" checked="checked" id="typeaub" value="user"> User
                           
                        </div>           
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Name</label>
                          
                                <input type="text" name="name" class="form-control" id="name" placeholder="Name" maxlength="255" required>
                                <h5 id="usercheck" style="color: red;" >
					                          **Username is missing
			                          </h5>
                          
                          </div>

    
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Email</label>
                                <input type="email" class="form-control" id="email" name="email" placeholder="e.g.: abc@xyz.com" required>
                                <h5 id="emailvalid" style="color: red;" >
					                          **Your email must be a valid email
			                          </h5>

                         </div> 
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Mobile</label>
                                <input type="tel" class="form-control" id="phone" name="phone" minlength="10" maxlength="10" size="10" placeholder="ex.8980140000" required>
                                <h5 id="mobilecheck" style="color: red;" >
					                          **Mobile Number is missing
			                          </h5>
                        </div>
    
                        
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Address</label>
                            <textarea class="form-control" name="city" id="city" rows="3"></textarea>
                            <h5 id="addresscheck" style="color: red;" >
					                          **Address is missing
			                          </h5>
                        </div>

    
                    </div> 
    
                <div class="col-lg-6 ">       
                        
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Birthday</label>
                                <input type="date" name="birthdate" id="birthdate" class="form-control datepicker">
                                <h5 id="birthcheck" style="color: red;" >
					                          **Birthdate isn't Selected
			                          </h5>
                            </div>
    
                                 
                            <div class="form-group">
                              <label for="formGroupExampleInput2">Skills:</label>
                                <select class="selectpicker form-control" name="skills[]" id="skills" multiple data-live-search="true" required>
                                      
                                <?php 
                                $result = mysqli_query($conn,"SELECT * FROM skills");
                                while($row = mysqli_fetch_assoc($result))
                                {
                                  # code...
                                  ?>
                                    <?php
                                    $ida = $row['id']; 
                                    ?>
                                    <option value="<?php echo $ida; ?>"><?= $row['name']; ?></option>
                               <?php

                                }
                                
                                ?>
                               </select>
                               <h5 id="skillcheck" style="color: red;" >
					                          **skill isn't Selected
			                          </h5>
                            </div>
    
                      
                            <label for="formGroupExampleInput2">Profile Pic:</label>
                            <div class="custom-file">
                               <input type="file"  onchange="readURL(this);" class="custom-file-input" id="profilepic" name="profilepic" required>                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                             </div>
                             <h5 id="profilecheck" style="color: red;" >
					                          **image isn't Selected
			                          </h5>
                    
                            <div class="form-group">
                                <img src="#"  id="blah" class="form-group" alt="">
                            </div>
    
                            <div class="form-group">
                                    <label for="formGroupExampleInput2">Password</label>
                                    <input type="password" class="form-control" name="password" id="password" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" id="password"   data-toggle="tooltip" data-placement="top" title="Min characters 8 digit Atleast 1 uppercase, lowercase and special character" required>                    
                                    <h5 id="passcheck" style="color: red;">
			                              	**Please Insert the password
			                              </h5>
                            </div>
    
    
                            <div class="form-group">
                              <label for="formGroupExampleInput2">Confirm Password</label>
                                <input type="password" class="form-control" id="cpassword" name="cpassword" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" placeholder="Re-enter Password" required>
                                  <h5 id="conpasscheck" style="color: red;">
			                            	**Password didn't match
			                            </h5>
                            </div>
                    
                </div>                       
                 
            </div>

                <div class="row text-center">
                    <div class="col">
                        <div class="form-group">
                            <input type="button" class="btn btn-primary butsave" name="butsave" id="butsave" value="Submit"/>
                        </div>
                    </div>        
                </div>
    
        </form>
             
    </div>


  </div>
     
    </div>
  </div>
</div></div>
<!-- Modal Add User End-->

<!-- Modal- Edit User Start -->
<div class="modal fade" style="font-size: 16px;" id="editModalEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="container">
    
          
        <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </div>
        

            <form id="fupForm2" class="fupForm2" name="form2" method="post" enctype="multipart/form-data">
            <div class="row">
            <input type="text" name="idup" id="idup" value="" hidden>

    
                  <div class="col-lg-6" >   
                    
                        <div class="form-group">
                          <label for="exampleFormControlTextarea1">User Type:</label>
                           <div id="adminType"> 
                                <input type="radio" name="typeau2"  id="typeA" value="admin">Admin
                                <input type="radio" name="typeau2" id="typeU" value="user">User  
                              </div>
                        </div>           
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Name</label>
                          
                                <input type="text" name="name2" class="form-control" id="name2" placeholder="Name" maxlength="255" value="" required>
                                <h5 id="usercheck2" style="color: red;" >
					                          **Username is missing
			                          </h5>
                          
                          </div>

    
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Email</label>
                                <input type="email" class="form-control" id="email2"  value=""name="email2" placeholder="e.g.: abc@xyz.com" required>
                                <h5 id="emailvalid2" style="color: red;" >
					                          **Your email must be a valid email
			                          </h5>

                         </div> 
                        
                        <div class="form-group">
                                <label for="formGroupExampleInput2">Mobile</label>
                                <input type="tel" class="form-control" id="phone2" name="phone2" value="" minlength="10" maxlength="10" size="10" placeholder="ex.8980140000" required>
                                <h5 id="mobilecheck2" style="color: red;" >
					                          **Mobile Number is missing
			                          </h5>
                        </div>
    
                        
                        <div class="form-group">
                            <label for="exampleFormControlTextarea1">Address</label>
                             <textarea class="form-control" name="city2" value="" id="city2" rows="3"></textarea>
                            <h5 id="addresscheck2" style="color: red;" >
					                          **Address is missing
			                          </h5>
                        </div>

    
                    </div> 
    
                <div class="col-lg-6 ">       
                        
                            <div class="form-group">
                                <label for="exampleFormControlTextarea1">Birthday</label>
                                <input type="date" name="birthdate2"value="" id="birthdate2" class="form-control datepicker">
                                <h5 id="birthcheck2" style="color: red;" >
					                          **Birthdate isn't Selected
			                          </h5>
                            </div>
    
                                 
                            <div class="form-group">
                              <label for="formGroupExampleInput2">Skills:</label>
                                <select class="selectpicker form-control" name="skillsE[]" id="skills2" multiple data-live-search="true" required>
                                <?php 
                                $result = mysqli_query($conn,"SELECT * FROM skills");
                                while($row = mysqli_fetch_assoc($result))
                                {
                                  # code...
                                  ?>
                                  $a = "";

                                    <?php
                                    $ida = $row['id']; 
                                    ?>
                                    <option value="<?php echo $ida; ?>" ><?= $row['name']; ?></option>
                               <?php

                                }
                                
                                ?>
                               </select>
                               <h5 id="skillcheck2" style="color: red;" >
					                          **skill isn't Selected
			                          </h5>
                            </div>
    
                      
                            <label for="formGroupExampleInput2">Profile Pic:</label>
                            <div class="custom-file">
                               <input type="file"  onchange="readURL(this);" class="custom-file-input" id="profilepic2" name="profilepic2" required>                              <label class="custom-file-label" for="inputGroupFile01">Choose file</label>
                             </div>
                             
                    
                            <div class="form-group">
                                <img src="#"  id="blah2" size class="form-group" alt="">
                            </div>
    
                            <div class="form-group">
                                    <label for="formGroupExampleInput2">Password</label>
                                    <input type="password" class="form-control" name="password2" id="password2" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" id="password2"   data-toggle="tooltip" data-placement="top" title="Min characters 8 digit Atleast 1 uppercase, lowercase and special character" required>                    
                                    <h5 id="passcheck2" style="color: red;">
			                              	**Please Insert the password
			                              </h5>
                            </div>
    
    
                            <div class="form-group">
                              <label for="formGroupExampleInput2">Confirm Password</label>
                                <input type="password" class="form-control" id="cpassword2" name="cpassword2" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$" placeholder="Re-enter Password" required>
                                  <h5 id="conpasscheck2" style="color: red;">
			                            	**Password didn't match
			                            </h5>
                            </div>
                    
                </div>                       
                 
            </div>

                <div class="row text-center">
                    <div class="col">
                        <div class="form-group">
                            <input type="button" class="btn btn-primary butsave" name="butupdate" id="btnupdate" value="Update"/>
                        </div>
                    </div>        
                </div>
    
        </form>
             
    </div>


  </div>
     
    </div>
  </div>
</div></div>
<!-- Modal Edit User End-->


<!-- Modal- Delete User Start -->
<div class="modal fade" style="font-size: 16px;" id="exampleModalDelete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure to Delete ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="container">
    
      <div class="form-group">
			  <label for="email">Delete User </label>
        <input type="text" class="form-control" id="edemail" value="" hidden>
    </div>
		
    <input type="button" name="delete" class="btn btn-danger " value="Delete" id="btndelete">

          
        <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </div>
        
             
    </div>


  </div>
     
    </div>
  </div>
</div></div>
<!-- Modal Delete User End-->



<!-- Modal- Update Status Start -->
<div class="modal fade" style="font-size: 16px;" id="exampleModalStatus" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Are You Sure to Delete ?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <div class="container">
    
      <div class="form-group">
			  <label for="email">Update User Status</label>
        <input type="text" class="form-control" id="thisId" value="" hidden>
    </div>
		
    <input type="button" name="btnupt" class="btn btn-danger" value="Update Status" id="btnupt">

          
        <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
        </div>
        
             
    </div>


  </div>
     
    </div>
  </div>
</div></div>
<!-- Modal Update Status End-->




<!-- main div End down -->
</div>  

<script>

function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };
            
            reader.onload = function (e) {
                $('#blah2')
                    .attr('src', e.target.result)
                    .width(150)
                    .height(200);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

</script>

<script>

$(document).ready(function()
{
  $('#example').DataTable();


  
  $(document).on('click','.updateUp',function(){
    var putid = $(this).closest('tr').find('#emailid').val();
    $('#upid').val(putid);
    $('#idup').val(putid);
    
    $.ajax({
      url:"getData.php",
      type: "POST",
      dataType: 'JSON',
      data: {
            
            uid:putid
      },
      cache: false,
				success: function(dataResult)
        {
          
          if(dataResult.statusCode) 
          {          
            var typeVal = dataResult.data.type;      
            if(typeVal =="user")
            {
              $('#typeU').prop('checked', true)          
            }else{
              $('#typeA').prop('checked', true)          
            }

            var skillArr = dataResult.skillarr;
            console.log(skillArr);

            $('#name2').val(dataResult.data.name);
            $('#email2').val(dataResult.data.email);
            $('#phone2').val(dataResult.data.mobile);
            $('#city2').val(dataResult.data.address);
            $('#birthdate2').val(dataResult.data.birthdate);
            var path = '<?= BASE_URL.FOLDER_URL; ?>';
            var img = dataResult.data.profilepic;
	          $('#blah2').attr('src',`${path}${img}`) .width(150).height(200);
            
            var index;
            $('#updateSkills option').prop('selected', false);
            for( index = 0; index < dataResult.skillarr.length; index++ )
            {
              $('#skills2 option[value='+dataResult.skillarr[ index ]+']').prop('selected', true);
            }
            
          } else {
            alert(dataResult.message);
          }					
				},
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }       
      
    });
    console.log(putid);


  });

  $(document).on('click','#butupdate',function()
  {
    var goid = $('#upid').val();
    console.log(goid);
  
  });

  $(document).on('change','#activeChked',function(e){

    var putid = $(this).closest('tr').find('#emailid').val();
    var getid = $('#getid').val(putid);
    var th = $('#getid').val();
    
    if(e.target.unchecked){
     $('#exampleModalStatus').modal();
   }
    
  });
  
  $(document).on('change','#activeChk',function(e){
    
    var putid = $(this).closest('tr').find('#emailid').val();
    var getid = $('#getid').val(putid);
    var th = $('#getid').val();
    
    if(e.target.unchecked){
     $('#exampleModalStatus').modal();
   }

  });


  $(document).on('click','#btnupt',function(){
      var thId = $('#getid').val();
      console.log(thId);

      var deactive = 'yes';

      $.ajax({
      url:"updateStatus.php",
      type: "POST",
      dataType: 'JSON',
      data: {
            status:deactive,
            id:thId
      },
      cache: false,
				success: function(dataResult)
        {
          
          if(dataResult.statusCode) 
          {          
            alert(dataResult.message);
            location.reload();
            
          } else {
            alert(dataResult.message);
          }					
				},
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }       
        

      });
    

  });


	
// Validate name
  $('#usercheck').hide();	
	let usernameError = false;
	$('#name').on('keyup',function () {
		validateUsername();
	});	
	function validateUsername()
	{
		let usernameValue = $('#name').val();
		if (usernameValue.length == '') {
		$('#usercheck').show();
			usernameError = false;
			return false;
			}
		else if((usernameValue.length < 3)||
				(usernameValue.length > 10)) {
			$('#usercheck').show();
			$('#usercheck').html("**length of username must be between 3 and 10");
      usernameError = false;
      return false;
    }
		else {
      $('#usercheck').hide();
      usernameError = true;
    }
	}

// Validate Mobile
$('#mobilecheck').hide();	
let phoneError = false;
$(document).on('keyup',function () {
validatePhone();
});	
function validatePhone()
{
let phoneValue = $('#phone').val();
var regex = /^(\s)*[\d\+\(\)\- x]{4,}$/;
  if (phoneValue.length == '')
  {
    $('#mobilecheck').show();
	  phoneError = false;
	  return false;
	}else if(!(regex.test(phoneValue)))
  {
     $('#mobilecheck').show();
     $('#mobilecheck').html("**Insert Number Only");
     phoneError = false;
     return false;

  }
else if((phoneValue.length < 10)||
		(phoneValue.length > 10)) {
	$('#mobilecheck').show();
	$('#mobilecheck').html("**length of Mobilenumber must be 10");
  phoneError = false;
  return false;
}
else {
  phoneError = true;
	$('#mobilecheck').hide();
  return false;
	}
}

// Validate Address
$('#addresscheck').hide();	
let addressError = false;
$(document).on('keyup','#city',function () {
validateCity();
});	
function validateCity()
{
let cityValue = $('#city').val();
if (cityValue.length == '') {
$('#addresscheck').show();
	addressError = false;
	return false;
	}
else if((cityValue.length == '')) {
	$('#addresscheck').show();
	$('#addresscheck').html("**Address must be Filld");
	 addressError = false;
	return false;
	}
else {
  addressError = true;
  $('#addresscheck').hide();
  return false;
	}
}

// Validate Birthdate
$('#birthcheck').hide();	
let birthError = false;
$(document).on('keyup','#birthdate',function () {
	validateBirth();
});	
function validateBirth()
{
	let birthValue = $('#birthdate').val();
 	if (birthValue.length == '') {
	$('#birthcheck').show();
		birthError = false;
		return false;
		}
	else {
    $('#birthcheck').hide();
    birthError = true;
    return false;
		}
}

// Validate skill
$('#skillcheck').hide();	
let skillError = false;
$(document).on('keyup','#skills',function ()
{
	validateSkills();
});	
function validateSkills()
{
	let skillValue = $('#skills').val();
  if (skillValue.length == '') {
	$('#skillcheck').show();
		skillError = false;
		return false;
		}
	else {
    $('#skillcheck').hide();
    skillError = true;
    return false;
		}
}

// Validate Profile
$('#profilecheck').hide();	
let profileError = false;
$('#profilepic').keyup(function () {
	validateProfile();
});	
function validateProfile()
{
	let profileValue = $('#profilepic').val();
  if (profileValue.length == '') {
	$('#profilecheck').show();
  profileError = false;
		return false;
		}
	else {
    $('#profilecheck').hide();
    profileError = true;
		}
}


// Validate Password
$('#passcheck').hide();
let passwordError = true;
$('#password').keyup(function () {
	validatePassword();
});
function validatePassword() 
{
	let passwrdValue =
		$('#password').val();
	if (passwrdValue.length == '') {
		$('#passcheck').show();
		passwordError = false;
		return false;
	}
  var regex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if(regex.test(passwrdValue))
  {

	if ((passwrdValue.length < 8)||
		(passwrdValue.length > 10)) {
		$('#passcheck').show();
		$('#passcheck').html("**length of your password must be between 8 and 10");
		$('#passcheck').css("color", "red");
		passwordError = false;
		return false;
	} else {
		$('#passcheck').hide();
    passwordError = true;
	}
 }
 else{

   $('#passcheck').html("**Min characters 8 digit Atleast 1 uppercase, lowercase and special character");
   $('#passcheck').css("color", "red");
 }
}

		
// Validate Confirm Password
$('#conpasscheck').hide();
	let confirmPasswordError = true;
	$('#cpassword').keyup(function () {
		validateConfirmPasswrd();
	});
	function validateConfirmPasswrd() 
  {
		let confirmPasswordValue =
			$('#cpassword').val();
		let passwrdValue =
			$('#password').val();

    if(confirmPasswordValue == '')
    {
      $('#conpasscheck').show();
			$('#conpasscheck').html(
				"**Please Insert the Cofirm Password");
			$('#conpasscheck').css(
				"color", "red");
			confirmPasswordError = false;
			return false;
		
    }else
    {

     if(passwrdValue != confirmPasswordValue) 
     {
			$('#conpasscheck').show();
			$('#conpasscheck').html(
				"**Password didn't Match");
			$('#conpasscheck').css(
				"color", "red");
			confirmPasswordError = false;
			return false;
		} else {
			confirmPasswordError = true;
			$('#conpasscheck').hide();
      return false;
		}
   }
	}

  var emailError = false;
  $('#emailvalid').hide();
  $('#email').on('keyup',function () {
		validateEmail();
	});	
	
  function validateEmail()
  {    
    var regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    var email = $('#email').val();
	  if(email=='')
    {
      $('#emailvalid').show();
      emailError = false;
    }

	  if(regex.test(email))
    {		
		  emailError = true;
		}
		else{
			
			emailError = false;
      console.error('RAMIZ');
		}
	

  }

// Delete Button
$(document).on('click','.deleteUp',function ()
{
  var femail = $(this).closest('tr').find('#emailid').val();
  $('#edemail').val(femail);
  console.log(femail);

});

$('#btndelete').on('click',function () {
  
  var edemail = $('#edemail').val();
  var deleted = 'Delete';
  if(edemail)
  {
    $.ajax({
      url: "addUser.php",
				type: "POST",
        dataType: 'JSON',
        data:
        {
					    deleteuser: edemail,
              deleted: deleted					
				},
				cache: false,
				success: function(dataResult)
        {
         	if(dataResult.statusCode)
          {
              location.load();
              alert(dataResult.message);
					}
					else 
          {
              alert(dataResult.message);
					}
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }	
			
    });
  
}});


$(document).on('click','#editUp',function()
{
  var femail = $(this).closest('tr').find('#emailid').val();
  $('#edemail').val(femail);
  console.log(femail);



});	

  
// Submitt button
	$('#butsave').click(function ()
   {
     var cc = $('#skills').val();
     console.log(cc);
     validateUsername();
     validateEmail();
     validatePhone();
     validateCity();     
     validateBirth();
     validateSkills();
     validateProfile();
     validatePassword();
     validateConfirmPasswrd();
          
    //  if(5>3)
		if ((usernameError == true)&& (emailError == true) && (phoneError == true) && (addressError == true)&& (birthError == true) && (skillError == true)&& (profileError == true)&& (passwordError == true)&&(confirmPasswordError == true)) 
    {
      save();
      return true;
		} else {
      alert('Please Fill THE FORM Complitily');
      return false;
		}
	});
  


  // -------------------------------------

  // $(document).on('click','.butsave',function(){
    function save()
    {
    var data = new FormData($('#fupForm')[0]);   
      $.ajax(
      {
        url: "addUser.php",
        type: "POST",
        dataType: 'JSON',
        data: data,
        processData: false,
        contentType: false,
        cache: false,
      
        success: function(dataResult)
        {
          if(dataResult.statusCode)
          {
            location.reload();
            $('#fupForm').find('input:text').val('');
            $('#success').html('Data added successfully !'); 						
            alert('User Added Successfully !!');
          }	
          else{
            alert(dataResult.message);
          }			     
       }
      });
    
     return false;
  }
});
<?php include 'put.js'; ?>
// Edit786S



// Validate name
$('#usercheck2').hide();	
	let usernameError2 = false;
	$('#name2').on('keyup',function () {
		validateUsername2();
	});	
	function validateUsername2()
	{
		let usernameValue2 = $('#name2').val();
		if (usernameValue2.length == '') {
		$('#usercheck2').show();
			usernameError2 = false;
			return false;
			}
		else if((usernameValue2.length < 3)||
				(usernameValue2.length > 10)) {
			$('#usercheck2').show();
			$('#usercheck2').html("**length of username must be between 3 and 10");
      usernameError2 = false;
      return false;
    }
		else {
      $('#usercheck2').hide();
      usernameError2 = true;
    }
	}

// Validate Mobile
$('#mobilecheck2').hide();	
let phoneError2 = false;
$(document).on('change',function () {
validatePhone2();
});	
function validatePhone2()
{
let phoneValue2 = $('#phone2').val();
var regex = /^(\s)*[\d\+\(\)\- x]{4,}$/;
  if (phoneValue2.length == '')
  {
    $('#mobilecheck2').show();
	  phoneError2 = false;
	  return false;
	}else if(!(regex.test(phoneValue2)))
  {
     $('#mobilecheck2').show();
     $('#mobilecheck2').html("**Insert Number Only");
     phoneError2 = false;
     return false;

  }
else if((phoneValue2.length < 10)||
		(phoneValue2.length > 10)) {
	$('#mobilecheck2').show();
	$('#mobilecheck2').html("**length of Mobilenumber must be 10");
  phoneError2 = false;
  return false;
}
else {
  phoneError2 = true;
	$('#mobilecheck2').hide();
  return false;
	}
}

// Validate Address
$('#addresscheck2').hide();	
let addressError2 = false;
$(document).on('keyup','#city2',function () {
validateCity2();
});	
function validateCity2()
{
let cityValue2 = $('#city2').val();
if (cityValue2.length == '') {
$('#addresscheck2').show();
	addressError2 = false;
	return false;
	}
else if((cityValue2.length == '')) {
	$('#addresscheck2').show();
	$('#addresscheck2').html("**Address must be Filld");
	 addressError2 = false;
	return false;
	}
else {
  addressError2 = true;
  $('#addresscheck2').hide();
  return false;
	}
}

// Validate Birthdate
$('#birthcheck2').hide();	
let birthError2 = false;
$(document).on('keyup','#birthdate2',function () {
	validateBirth2();
});	
function validateBirth2()
{
	let birthValue2 = $('#birthdate2').val();
 	if (birthValue2.length == '') {
	$('#birthcheck2').show();
		birthError2 = false;
		return false;
		}
	else {
    $('#birthcheck2').hide();
    birthError2 = true;
    return false;
		}
}

// Validate skill
$('#skillcheck2').hide();	
let skillError2 = false;
$(document).on('keyup','#skills2',function ()
{
	validateSkills2();
});	
function validateSkills2()
{
	let skillValue2 = $('#skills2').val();
  if (skillValue2.length == '') {
	$('#skillcheck2').show();
		skillError2 = false;
		return false;
		}
	else {
    $('#skillcheck2').hide();
    skillError2 = true;
    return false;
		}
}

// Validate Password
$('#passcheck2').hide();
let passwordError2 = true;
$('#password2').keyup(function () {
	validatePassword2();
});
function validatePassword2() 
{
	let passwrdValue2 =
		$('#password2').val();
	if (passwrdValue2.length == '') {
		$('#passcheck2').show();
		passwordError2 = false;
		return false;
	}
  var regex2 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if(regex2.test(passwrdValue2))
  {

	if ((passwrdValue2.length < 8)||
		(passwrdValue2.length > 10)) {
		$('#passcheck2').show();
		$('#passcheck2').html("**length of your password must be between 8 and 10");
		$('#passcheck2').css("color", "red");
		passwordError2 = false;
		return false;
	} else {
		$('#passcheck2').hide();
    passwordError2 = true;
	}
 }
 else{
    $('#passcheck2').show();
   $('#passcheck2').html("**Min characters 8 digit Atleast 1 uppercase, lowercase and special character");
   $('#passcheck2').css("color", "red");
 }
}

		
// Validate Confirm Password
$('#conpasscheck2').hide();
	var confirmpasswordError2 = false;
	$('#cpassword2').keyup(function () {
		validateConfirmPasswrd2();
	});
	function validateConfirmPasswrd2() 
  {
		let confirmPasswordValue2 =
			$('#cpassword2').val();
		let passwrdValue2 =
			$('#password2').val();

    if(confirmPasswordValue2 == '')
    {
      $('#conpasscheck2').show();
			$('#conpasscheck2').html(
				"**Please Insert the Cofirm Password");
			$('#conpasscheck2').css(
				"color", "red");
			confirmpasswordError2 = false;

			return false;
		
    }else
    {

     if(passwrdValue2 != confirmPasswordValue2) 
     {
			$('#conpasscheck2').show();
			$('#conpasscheck2').html(
				"**Password didn't Match");
			$('#conpasscheck2').css(
				"color", "red");
			confirmpasswordError2 = false;
			return false;
		} else {
			confirmpasswordError2 = true;
			$('#conpasscheck2').hide();
      return false;
		}
   }
	}

  var emailError2 = false;
  $('#emailvalid2').hide();
  $('#email2').on('keyup',function () {
		validateEmail2();
	});	
	
  function validateEmail2()
  {    
    var regex = /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;
    var email = $('#email2').val();
	  if(email=='')
    {
      $('#emailvalid2').show();
      emailError2 = false;
    }

	  if(regex.test(email))
    {		
		  emailError2 = true;
		}
		else{
			
			emailError2 = false;
      console.error('RAMIZ2rja');
		}
	

  }




// Edit786E




// Edit button
$('#btnupdate').click(function ()
   {
     var cc = $('#skillsE').val();
     console.log(cc);
     validateUsername2();
     validateEmail2();
     validatePhone2();
     validateCity2();     
     validateBirth2();
     validateSkills2();
    //  validateProfile2();
     validatePassword2();
     validateConfirmPasswrd2();
          
  
		if ((usernameError2 == true)&& (emailError2 == true)  && (phoneError2 == true) &&(addressError2 == true)&& (birthError2 == true) && (skillError2 == true) && (passwordError2 == true)) 
    {
      edit();
      return true;
		} else {
      alert('Please Fill THE FORM Complitily');
      return false;
		}
	});

function edit()
    {
    var data = new FormData($('#fupForm2')[0]);   
      $.ajax(
      {
        url: "editUser.php",
        type: "POST",
        dataType: 'JSON',
        data: data,
        processData: false,
        contentType: false,
        cache: false,
      
        success: function(dataResult)
        {
          if(dataResult.statusCode)
          {
            location.reload();
            $('#fupForm2').find('input:text').val('');
            $('#success').html('Data added successfully !'); 						
            alert('User Edited Successfully !!');
          }	
          else{
            alert(dataResult.message);
          }			     
       },
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }       
        

      });
    
     return false;
  }


 </script>


   
<?php

include 'basic_files/lower.php';

 ?>