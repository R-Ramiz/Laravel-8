<?php

error_reporting(0);
session_start();

include 'basic_files/database.php';
 include 'basic_files/upper.php';
include 'basic_files/navbar.php';

$email = $_SESSION['email'];
 
  $check = mysqli_query($conn,"SELECT * FROM `users` WHERE `email`= '$email'");
  $row = mysqli_fetch_assoc($check);

  $id = $row['id'];
 $oldPass = $row['password'];

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  width: 130px;
  position: fixed;
  z-index: 1;
  top: 20px;
  left: 10px;
  background: #eee;
  overflow-x: hidden;
  padding: 8px 0;
  margin-top: 50px;
  
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 16px;
  color: #2196F3;
  display: block;
}

.sidenav a:hover {
  color: #064579;
}

.main {
  margin-left: 440px; /* Same width as the sidebar + left position in px */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
   
</head>
<body>

<div class="sidenav">
  <a href="home.php">Dashbord</a>
  <a href="userMaster.php">User Master</a>
  <a href="skillMaster.php">Skill Master</a>
  <a href="changePassword.php">Change Password</a>
</div>

<div class="main">
<div class="container mx-2 my-2" style="font-size:24px;">

<div class="row">

<form method="POST">
  <input type="text" id="userId" value="<?= $id; ?>" hidden>
  <div class="form-group">
    <label for="inputPassword3" class="label">Old Password :</label>
          <input type="password" class="form-control oldpwd" id="oldpwd"  placeholder="Old Password">
          <h5 id="oldpasscheck" style="color: red;">
			                              	**Please Insert the Old password
			                              </h5>
  </div>

  <div class="form-group">
    <label for="inputPassword3" class="label">New Password :</label>
          <input type="password" class="form-control newpwd" id="newpwd" placeholder="New Password">
          <h5 id="passcheck" style="color: red;">
			                              	**Please Insert the password
			                              </h5>
  </div>
  
    
  <div class="form-group">
    <label for="inputPassword3" class="label">Confirm Password :</label>
          <input type="password" class="form-control cnewpwd" id="cnewpwd" placeholder="Confirm Password">
          <h5 id="conpasscheck" style="color: red;">
			                            	**Password didn't match
			                            </h5>
       </div>
  

  
          <button type="button" name="change" id="btnupdate" class="btn btn-primary mx-5">Update</button>
  
  
        </div>
</form>
</div>
</div>
</div>

   

<script>


$(document).ready(function()
{
  $('#oldpasscheck').hide(); 
  $('#passcheck').hide();
  $('#conpasscheck').hide();


function validatePassword2() 
{
	let passwrdValue2 =
		$('#newpwd').val();
	if (passwrdValue2.length == '') {
		$('#passcheck').show();
		passwordError2 = false;
		return false;
	}
  var regex2 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
  if(regex2.test(passwrdValue2))
  {

	if ((passwrdValue2.length < 8)||
		(passwrdValue2.length > 10)) {
		$('#passcheck').show();
		$('#passcheck').html("**length of your password must be between 8 and 10");
		$('#passcheck').css("color", "red");
		passwordError2 = false;
		return false;
	} else {
		$('#passcheck').hide();
    passwordError2 = true;
	}
 }
 else{
    $('#passcheck').show();
   $('#passcheck').html("**Min characters 8 digit Atleast 1 uppercase, lowercase and special character");
   $('#passcheck').css("color", "red");
 }
}


$(document).on('click','#btnupdate',function()
{ 
  validatePassword2();


var userId =  $('#userId').val();
var oldpwd =  $('#oldpwd').val();
var newpwd =  $('#newpwd').val();
var cnewpwd =  $('#cnewpwd').val();

if(oldpwd == '')
{
  $('#oldpasscheck').show();

}else if(newpwd == '')
{
  $('#passcheck').show();

}else if(cnewpwd == '')
{
  $('#conpasscheck').show();
}else if(newpwd != cnewpwd){
  alert('Password and Confirm Password Doesn\'t Match');
}
else{

$.ajax({
        url: "pwdChange.php",
				type: "POST",
        dataType:'JSON',
        data:
        {     userId:userId,
              oldpwd:oldpwd,
					    newpwd:newpwd,
              cnewpwd:cnewpwd			
				},
				cache: false,
				success: function(dataResult)
        {
          if(dataResult.statusCode)
          {
              alert(dataResult.message);
              location.reload();
					}
					else 
          {
             alert(dataResult.message);
					}
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) 
        { 
          alert("Status: " + textStatus); 
          alert("Error: " + errorThrown); 
        }
  });
  
}


});





});



</script>





<?php

include 'basic_files/lower.php';

 ?>